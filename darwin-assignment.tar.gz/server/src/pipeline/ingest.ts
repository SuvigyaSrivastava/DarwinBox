import { parse } from "csv-parse/sync";
import * as XLSX from "xlsx";
import { readFileSync } from "node:fs";
import path from "node:path";

export interface SourceFile {
  filename: string;
  columns: string[];
  rows: Record<string, string>[];
}

/** Parses a CSV or XLSX file into a uniform column/row shape. Blank cells
 * become empty strings (not undefined) so downstream code has one shape to
 * reason about. */
export function parseSourceFile(filePath: string): SourceFile {
  const filename = path.basename(filePath);
  const ext = path.extname(filename).toLowerCase();

  let rows: Record<string, string>[];

  if (ext === ".xlsx" || ext === ".xls") {
    const wb = XLSX.readFile(filePath);
    const sheet = wb.Sheets[wb.SheetNames[0]];
    rows = XLSX.utils.sheet_to_json(sheet, { defval: "", raw: false });
  } else {
    // Also handles files named *.xlsx.csv (our sample contractor file is a
    // CSV masquerading with an .xlsx-flavored name to simulate an export
    // that started life as a spreadsheet).
    const raw = readFileSync(filePath, "utf-8");
    rows = parse(raw, {
      columns: true,
      skip_empty_lines: true,
      trim: false,
      bom: true,
    });
  }

  const columns = rows.length > 0 ? Object.keys(rows[0]) : [];

  // Normalize every cell to a trimmed string (preserve internal content,
  // just strip outer whitespace at the parse boundary so "  Mark " and
  // "Mark" are the same value going into reconciliation).
  const normalizedRows = rows.map((row) => {
    const out: Record<string, string> = {};
    for (const col of columns) {
      const v = row[col];
      out[col] = v === undefined || v === null ? "" : String(v).trim();
    }
    return out;
  });

  return { filename, columns, rows: normalizedRows };
}

export function parseSourceFiles(filePaths: string[]): SourceFile[] {
  return filePaths.map(parseSourceFile);
}
